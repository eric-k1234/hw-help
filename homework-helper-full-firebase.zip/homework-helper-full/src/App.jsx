import React, { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  initializeApp, getApps
} from "firebase/app";
import {
  getAuth, GoogleAuthProvider, onAuthStateChanged,
  signInWithPopup, signOut
} from "firebase/auth";
import {
  getFirestore, collection, doc, getDoc, onSnapshot, addDoc, setDoc,
  updateDoc, query, where, orderBy, limit, serverTimestamp, increment
} from "firebase/firestore";
import {
  getStorage, ref as storageRef, uploadBytes, getDownloadURL
} from "firebase/storage";

/** 🔧 Firebase config — replace with your project settings (safe to expose) */
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
};
if (!getApps().length) initializeApp(firebaseConfig);

const auth = getAuth();
const db = getFirestore();
const storage = getStorage();

/** Helpers */
function useAuth() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    return onAuthStateChanged(auth, async (u) => {
      setUser(u); setLoading(false);
      if (!u) return;
      const uref = doc(db, "users", u.uid);
      const snap = await getDoc(uref);
      if (!snap.exists()) {
        await setDoc(uref, {
          uid: u.uid,
          displayName: u.displayName,
          photoURL: u.photoURL,
          email: u.email,
          points: 0,
          createdAt: serverTimestamp(),
        });
      }
    });
  }, []);
  return { user, loading };
}

function useColl(path, constraints = []) {
  const [items, setItems] = useState([]);
  useEffect(() => {
    const q = query(collection(db, path), ...constraints);
    const unsub = onSnapshot(q, (snap) => {
      const arr = [];
      snap.forEach((d) => arr.push({ id: d.id, ...d.data() }));
      setItems(arr);
    });
    return () => unsub();
  }, [path, JSON.stringify(constraints)]);
  return items;
}

const Rank = (pts) => {
  if (pts >= 1000) return { name: "Legend", className: "pill" };
  if (pts >= 500) return { name: "Gold Helper", className: "pill" };
  if (pts >= 250) return { name: "Silver Helper", className: "pill" };
  return { name: "Helper", className: "pill" };
};

/** UI atoms (no external UI lib) */
const Button = ({ className="", style={}, ...props }) => (
  <button className={"btn " + className} style={style} {...props} />
);
const Card = ({ className="", ...props }) => (
  <div className={"card " + className} {...props} />
);

/** Auth controls */
function SignIn() {
  const handle = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      alert("Signed in");
    } catch (e) {
      alert(e?.message || "Sign-in failed");
    }
  };
  return <Button className="gold" onClick={handle}>Sign in with Google</Button>;
}

function UserMenu({ user }) {
  const [points, setPoints] = useState(0);
  useEffect(() => {
    if (!user) return;
    return onSnapshot(doc(db, "users", user.uid), (d) => {
      setPoints(d.data()?.points || 0);
    });
  }, [user?.uid]);
  const r = Rank(points);
  return (
    <div className="row" style={{gap:8}}>
      <div className="avatar">{user?.displayName?.[0] || "U"}</div>
      <div>
        <div className="small" style={{fontWeight:700}}>{user?.displayName}</div>
        <div className="small muted">{user?.email}</div>
      </div>
      <span className="pill right">{r.name}</span>
      <Button className="ghost" onClick={() => signOut(auth)}>Sign out</Button>
    </div>
  );
}

/** Sidebar: classes */
function ClassSidebar({ activeClassId, onSelect }) {
  const classes = useColl("classes", [orderBy("name", "asc")]);
  const [name, setName] = useState("");
  const { user } = useAuth();

  const addClass = async () => {
    if (!user) return alert("Sign in to add a class");
    const n = name.trim();
    if (!n) return;
    await addDoc(collection(db, "classes"), { name: n, createdAt: serverTimestamp() });
    setName("");
  };

  return (
    <Card className="pad" style={{height:"fit-content"}}>
      <div className="row-justify">
        <div style={{fontWeight:800, color:"var(--green-700)"}}>Classes</div>
        <span className="badge">Green & Gold</span>
      </div>
      <div className="list" style={{marginTop:12}}>
        <Button className={activeClassId===null? "ghost": ""} onClick={()=>onSelect(null)}>All Questions</Button>
        {classes.map((c) => (
          <Button key={c.id} className={activeClassId===c.id? "ghost": ""} onClick={()=>onSelect(c.id)}>{c.name}</Button>
        ))}
      </div>
      <div style={{marginTop:12}}>
        <div className="small muted" style={{marginBottom:6}}>Add class</div>
        <div className="row">
          <input className="input" placeholder="e.g. Algebra II" value={name} onChange={e=>setName(e.target.value)}/>
          <Button className="green" onClick={addClass}>Add</Button>
        </div>
      </div>
    </Card>
  );
}

/** New Question */
function NewQuestion({ currentClassId }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button className="gold" onClick={()=>setOpen(true)}>New Question</Button>
      {open && <NewQuestionDialog onClose={()=>setOpen(false)} currentClassId={currentClassId}/>}
    </>
  );
}
function NewQuestionDialog({ onClose, currentClassId }) {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [classId, setClassId] = useState(currentClassId);
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const classes = useColl("classes", [orderBy("name", "asc")]);
  const { user } = useAuth();

  useEffect(()=>setClassId(currentClassId), [currentClassId]);

  const create = async () => {
    if (!user) return alert("Sign in to post");
    if (!title.trim() || !classId) return alert("Title and class required");
    try {
      setBusy(true);
      let attachmentURL = null;
      if (file) {
        const sref = storageRef(getStorage(), `attachments/${user.uid}/${Date.now()}_${file.name}`);
        const snap = await uploadBytes(sref, file);
        attachmentURL = await getDownloadURL(snap.ref);
      }
      await addDoc(collection(db, "questions"), {
        title: title.trim(),
        body: body.trim(),
        classId,
        createdAt: serverTimestamp(),
        authorId: user.uid,
        authorName: user.displayName,
        authorPhoto: user.photoURL,
        attachmentURL,
        postsCount: 0,
      });
      onClose();
      alert("Question posted");
    } finally { setBusy(false); }
  };

  return (
    <div className="card pad" style={{position:"fixed", inset:"10% 10% auto 10%", background:"white", zIndex:50}}>
      <div className="row-justify">
        <div style={{fontWeight:800}}>Ask a homework question</div>
        <Button className="ghost" onClick={onClose}>Close</Button>
      </div>
      <div className="list" style={{marginTop:12}}>
        <input className="input" placeholder="Short title" value={title} onChange={e=>setTitle(e.target.value)} />
        <textarea className="input" rows="5" placeholder="Describe the problem." value={body} onChange={e=>setBody(e.target.value)} />
        <div className="row">
          <select className="input" value={classId || ""} onChange={e=>setClassId(e.target.value || null)}>
            <option value="">Select class</option>
            {classes.map((c)=> <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <input type="file" accept="image/*" onChange={(e)=>setFile(e.target.files?.[0] || null)} />
        </div>
        <div className="row" style={{justifyContent:"flex-end"}}>
          <Button className="green" disabled={busy} onClick={create}>{busy? "Posting..." : "Post"}</Button>
        </div>
      </div>
    </div>
  );
}

/** Feed */
function QuestionsFeed({ activeClassId, onOpen }) {
  const [search, setSearch] = useState("");
  const questions = useColl("questions", [orderBy("createdAt", "desc")]);
  const classes = useColl("classes", []);
  const classNameById = useMemo(()=>Object.fromEntries(classes.map(c=>[c.id, c.name])), [classes]);

  const filtered = useMemo(()=> {
    return questions
      .filter((q)=> !activeClassId || q.classId===activeClassId)
      .filter((q)=> !search.trim() || (q.title?.toLowerCase().includes(search.toLowerCase()) || q.body?.toLowerCase().includes(search.toLowerCase())));
  }, [questions, activeClassId, search]);

  return (
    <div>
      <div className="row" style={{gap:8, marginBottom:12}}>
        <input className="input" placeholder="Search questions" value={search} onChange={(e)=>setSearch(e.target.value)} />
      </div>
      <div className="grid" style={{gridTemplateColumns:"1fr 1fr 1fr"}}>
        <AnimatePresence mode="popLayout">
          {filtered.map((q)=>(
            <motion.div key={q.id} layout initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-8}}>
              <Card className="pad">
                <div className="row-justify">
                  <div className="row" style={{gap:8}}>
                    <div className="avatar">{q.authorName?.[0]||"?"}</div>
                    <div>
                      <div className="small" style={{fontWeight:700}}>{q.authorName||"Anon"}</div>
                      <div className="small muted">{q.createdAt?.toDate ? new Date(q.createdAt.toDate()).toLocaleString() : ""}</div>
                    </div>
                  </div>
                  <span className="pill">{classNameById[q.classId] || "Class"}</span>
                </div>
                <div style={{marginTop:8, fontWeight:800, color:"var(--green-700)"}}>{q.title}</div>
                <div className="muted" style={{marginTop:6}}>{q.body}</div>
                {q.attachmentURL && <img className="img" src={q.attachmentURL} alt="attachment" />}
                <div className="row" style={{justifyContent:"space-between", marginTop:10}}>
                  <Button className="ghost" onClick={()=>onOpen(q)}>{q.postsCount||0} replies</Button>
                  <Button className="green" onClick={()=>onOpen(q)}>Open</Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}

/** Question detail */
function QuestionDetail({ q, onClose }){
  const posts = useColl("posts", [where("questionId","==", q?.id || "__"), orderBy("createdAt","asc")]);
  const { user } = useAuth();
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);

  const addPost = async () => {
    if (!user) return alert("Sign in to reply");
    const t = text.trim(); if (!t) return;
    try{
      setBusy(true);
      await addDoc(collection(db, "posts"), {
        questionId: q.id,
        text: t,
        createdAt: serverTimestamp(),
        authorId: user.uid,
        authorName: user.displayName,
        authorPhoto: user.photoURL,
        helpful: 0,
      });
      await updateDoc(doc(db, "questions", q.id), { postsCount: (q.postsCount||0)+1 });
      setText("");
    } finally { setBusy(false); }
  };

  const markHelpful = async (post) => {
    if (!user) return;
    await updateDoc(doc(db, "users", post.authorId), { points: increment(10) });
    await updateDoc(doc(db, "posts", post.id), { helpful: increment(1) });
    alert("Marked helpful (+10 points)");
  };

  return (
    <div className="card pad" style={{position:"fixed", inset:"6% 6% auto 6%", background:"white", zIndex:60, maxHeight:"88vh", overflow:"auto"}}>
      <div className="row-justify">
        <div style={{fontWeight:800, color:"var(--green-700)"}}>{q?.title}</div>
        <Button className="ghost" onClick={onClose}>Close</Button>
      </div>
      <div className="row" style={{gap:8, marginTop:8}}>
        <div className="avatar">{q?.authorName?.[0]||"?"}</div>
        <div className="small" style={{fontWeight:700}}>{q?.authorName}</div>
        <span className="pill right">Question</span>
      </div>
      <div className="muted" style={{marginTop:8, whiteSpace:"pre-wrap"}}>{q?.body}</div>
      {q?.attachmentURL && <img className="img" src={q.attachmentURL} alt="attachment" />}
      <div className="row" style={{gap:8, marginTop:12}}>
        <div className="small muted">Replies</div>
      </div>
      <div className="list" style={{marginTop:8}}>
        {posts.map((p)=>(
          <div key={p.id} className="card pad">
            <div className="row" style={{gap:8}}>
              <div className="avatar">{p.authorName?.[0]||"?"}</div>
              <div className="small" style={{fontWeight:700}}>{p.authorName}</div>
              <div className="right helpful" onClick={()=>markHelpful(p)}>Helpful: {p.helpful||0}</div>
            </div>
            <div style={{marginTop:8, whiteSpace:"pre-wrap"}}>{p.text}</div>
          </div>
        ))}
        {posts.length===0 && <div className="muted">Be the first to reply.</div>}
      </div>
      <div className="list" style={{marginTop:12}}>
        <textarea className="input" rows="3" placeholder="Write a helpful reply" value={text} onChange={e=>setText(e.target.value)} />
        <div className="row" style={{justifyContent:"flex-end"}}>
          <Button className="green" disabled={busy} onClick={addPost}>{busy? "Posting..." : "Reply"}</Button>
        </div>
      </div>
    </div>
  );
}

/** Leaderboard */
function Leaderboard(){
  const top = useColl("users", [orderBy("points","desc"), limit(10)]);
  return (
    <Card className="pad">
      <div className="row" style={{gap:8, marginBottom:8}}>
        <div className="pill" style={{background:"#fff7ed", borderColor:"#fed7aa", color:"#7c2d12"}}>Top Helpers</div>
      </div>
      <div className="list">
        {top.map((u, i)=>{
          const r = Rank(u.points||0);
          return (
            <div key={u.uid||i} className="row" style={{gap:10}}>
              <div className="pill" style={{background:"#fde68a", borderColor:"#f59e0b", color:"#7c2d12"}}>{i+1}</div>
              <div className="avatar">{u.displayName?.[0]||"?"}</div>
              <div style={{fontWeight:700}}>{u.displayName || "Student"}</div>
              <span className="pill right">{r.name}</span>
              <div style={{fontWeight:800, color:"var(--green-700)"}}>{u.points||0}</div>
            </div>
          );
        })}
        {top.length===0 && <div className="muted">No helpers yet. Start answering to earn points!</div>}
      </div>
    </Card>
  );
}

function Rewards(){
  return (
    <Card className="pad">
      <div className="row" style={{gap:8}}>
        <div className="pill">Monthly Rewards</div>
      </div>
      <div className="muted" style={{marginTop:6}}>
        #1 Helper earns a shout‑out and a prize every month. Keep it helpful and respectful.
      </div>
    </Card>
  );
}

/** App Shell */
export default function App(){
  const { user, loading } = useAuth();
  const [activeClassId, setActiveClassId] = useState(null);
  const [selected, setSelected] = useState(null);

  return (
    <div>
      <header>
        <div className="brand">
          <div className="logo">HH</div>
          <div>
            <div className="title">Homework Helper</div>
            <div className="subtitle">Study together • Rank up • Win monthly rewards</div>
          </div>
        </div>
        <div className="row">
          {!loading && (user ? <UserMenu user={user}/> : <SignIn/>)}
        </div>
      </header>

      <main className="container grid grid-2">
        <div className="grid">
          <div className="card pad">
            <div className="row-justify">
              <div>
                <div style={{fontWeight:800, color:"var(--green-700)"}}>{activeClassId? "Class questions":"All questions"}</div>
                <div className="muted">Upload questions, get help, and help others.</div>
              </div>
              <span className="pill">Green & Gold</span>
            </div>
          </div>
          <div className="row" style={{justifyContent:"space-between"}}>
            <NewQuestion currentClassId={activeClassId} />
          </div>
          <QuestionsFeed activeClassId={activeClassId} onOpen={(q)=>setSelected(q)} />
        </div>

        <div className="grid">
          <ClassSidebar activeClassId={activeClassId} onSelect={setActiveClassId} />
          <Rewards/>
          <Leaderboard/>
          <Card className="pad">
            <div style={{fontWeight:800, color:"var(--green-700)"}}>Tips</div>
            <ul className="muted">
              <li>Use clear titles like “Unit 3: Chain Rule #7”.</li>
              <li>Attach a photo of the problem to get faster help.</li>
              <li>Mark replies as helpful to reward helpers (+10 points).</li>
            </ul>
          </Card>
        </div>
      </main>

      <footer className="container small muted" style={{marginTop:24, textAlign:"center"}}>
        © {new Date().getFullYear()} Homework Helper — green & gold
      </footer>

      {selected && <QuestionDetail q={selected} onClose={()=>setSelected(null)} />}
    </div>
  );
}

/** Firestore collections created on write:
 * - users { uid, displayName, photoURL, email, points, createdAt }
 * - classes { name, createdAt }
 * - questions { title, body, classId, authorId, authorName, authorPhoto, attachmentURL, postsCount, createdAt }
 * - posts { questionId, text, authorId, authorName, authorPhoto, helpful, createdAt }
 *
 * Firebase Console:
 * - Authentication → Sign-in method → Enable Google; add authorized domain: <your-username>.github.io
 * - Firestore/Storage: Start in test mode (then tighten rules)
 * GitHub Pages:
 * - vite.config.js base must match your repo name (e.g., /homework-helper-full/)
 */
